This directory is for a few additional options for YUNG's Better Strongholds.
Options provided may vary by version.
This directory contains subdirectories for supported versions. The first time you run Better Strongholds, a version subdirectory will be created if that version supports advanced options.
For example, the first time you use Better Strongholds for MC 1.16 on Forge, the 'forge-1_16' subdirectory will be created in this folder.
If no subdirectory for your version is created, then that version probably does not support the additional options.
NOTE -- MOST OPTIONS CAN BE FOUND IN A CONFIG FILE OUTSIDE THIS FOLDER!
For example, on Forge 1.16 the file is 'betterstrongholds-forge-1_16.toml'.